public class exercicio5_Abenza {
    public static void main(String[] args) {
   for (int b = 0; b<=10; b++){
	for (int k = 0; k<=10; k++){
    System.out.println (b+" X "+ k + " o resultado é:" + k*b);
}
   }
     }
       }
