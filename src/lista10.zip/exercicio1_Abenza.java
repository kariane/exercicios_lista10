
public class exercicio1_Abenza {
    public static void main(String[] args) {
       int i;
     for(i=10; i>0;i--){
         System.out.println("Contagem regressiva: "+ i);
        
    }
    }
    }
    