
public class exercicio2_Abenza {
    public static void main(String[] args) {
        int i, soma=0;
        for(i=1;i<=100;i++){
            soma+=i;
           
        }
         System.out.println("A soma de todos é: "+ soma);
    }
 
}
